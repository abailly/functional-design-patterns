/**
 * Parallelization strategies.
 */
package fj.control.parallel;
